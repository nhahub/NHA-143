SELECT 
    COUNT(*) AS BlankCount
FROM 
    olist_customers_dataset_olist_customers_dataset
WHERE 
    customer_state IS NULL
    OR customer_state = ''
    OR customer_state = 'Blank'
    OR customer_state = '(Blank)';
