

UPDATE olist_closed_deals_dataset_olist_closed_deals_dataset
SET has_company = 'do not have a company'
WHERE has_company IS NULL;